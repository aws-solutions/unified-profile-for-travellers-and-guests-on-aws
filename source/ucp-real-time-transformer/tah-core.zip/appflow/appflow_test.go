package appflow

import "testing"

/**********
* Test Appflow
******************/
//TODO: create the flow dynamically
func TestAppflow(t *testing.T) {
	/*
		cfg := appflow.Init()
		flows, err := cfg.GetFlows([]string{"Customer_Profiles_test-domain-3_S3_clickstream_1661347126600", "Customer_Profiles_test-domain-3_S3_loyalty_1661347097449"})
		if err != nil {
			t.Errorf("[TestSQS]error getting batch of flows: %v", err)
		}
		if len(flows) != 2 {
			t.Errorf("[TestSQS] shoudl return 2 flows not %v", len(flows))
		}*/
}
