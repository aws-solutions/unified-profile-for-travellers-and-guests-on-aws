package connect

import "testing"

/*******
* CONNECT
*****/
func TestConnect(t *testing.T) {
	//connect := connect.Init("569b8cfc-1ca2-4676-a8be-27227eff69cc", "0229eb4c-57ed-4be1-a3fa-ae997fd0cc71", "eu-central-1", "+18335380956")
	//err := connect.Callback("+16172299659", map[string]string{"source": "inRoomOrder"})
	//if err != nil {
	//	t.Errorf("[core][Connect] call to connect shouuld not return and error. Error:" + err.Error())
	//}
	//t.Errorf("[core][Lambda] Error while invoking lambda %v", res2)
}
